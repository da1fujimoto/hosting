import React from 'react';

const renderBi = (data, begin, end, toggleState) => {
    return data.filter(d => d.index >= begin && d.index < end).map(d => {
        if(d.open) {
            return (
                <button
                    className="btn-floating btn-large waves-effect waves-light red"
                    style={{fontSize: "24px"}}
                    key={d.index}
                    onClick={toggleState}
                    >{d.index+1}
                </button>
            );
        } else {
            return (
                <button
                    className="btn-floating btn-large waves-effect waves-light blue lighten-4"
                    style={{fontSize: "24px", color: '#1e88e5'}}
                    key={d.index}
                    onClick={toggleState}
                    >{d.index+1}
                </button>
            );
        }
    })
}

const Bingo = props => {
    return (
        <div>
            <div className="row">
                <div className="col s1">
                    <button className="btn-floating btn-large waves-effect waves-light purple darken-1" style={{fontSize: "24px"}}>B</button>
                </div>
                <div className="col s11">
                    {renderBi(props.open, 0, 15, props.toggle)}
                </div>
            </div>
            <div className="row">
                <div className="col s1">
                    <button className="btn-floating btn-large waves-effect waves-light purple darken-1" style={{fontSize: "24px"}}>I</button>
                </div>
                <div className="col s11">
                    {renderBi(props.open, 15, 30, props.toggle)}
                </div>
            </div>
            <div className="row">
                <div className="col s1">
                    <button className="btn-floating btn-large waves-effect waves-light purple darken-1" style={{fontSize: "24px"}}>N</button>
                </div>
                <div className="col s11">
                    {renderBi(props.open, 30, 45, props.toggle)}
                </div>
            </div>
            <div className="row">
                <div className="col s1">
                    <button className="btn-floating btn-large waves-effect waves-light purple darken-1" style={{fontSize: "24px"}}>G</button>
                </div>
                <div className="col s11">
                    {renderBi(props.open, 45, 60, props.toggle)}
                </div>
            </div>
            <div className="row">
                <div className="col s1">
                    <button className="btn-floating btn-large waves-effect waves-light purple darken-1" style={{fontSize: "24px"}}>O</button>
                </div>
                <div className="col s11">
                    {renderBi(props.open, 60, 75, props.toggle)}
                </div>
            </div>
            {/* <div>{JSON.stringify(props.open.filter(d=>d.open))}</div> */}
        </div>
    );
};

export default Bingo;