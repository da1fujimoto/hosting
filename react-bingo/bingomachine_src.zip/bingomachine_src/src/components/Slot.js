import React from 'react';

class Slot extends React.Component {
    constructor(props) {
        super(props);
        this.state = {slot10: 0, slot1: 0, clearIntervalCb: null}
    }

    slotNumber(maxNum) {
        return Math.floor(Math.random()*maxNum);
    }

    slotRender = ({state, number}) => {
        if(state === 'slotting') {
            if(this.state.clearIntervalCb === null) {
                const clearIntervalCb = setInterval(() => {
                    this.setState({slot10: this.slotNumber(8), slot1: this.slotNumber(10)});
                }, 50);
        
                this.setState({clearIntervalCb});
            }
            return (
                <>
                    <div className="card purple darken-1 col s2" style={{height: '200px', fontSize: '100pt', color: '#FFF'}}>
                        {this.state.slot10}
                    </div>
                    <div className="card purple darken-1 col s2" style={{height: '200px', fontSize: '100pt', color: '#FFF'}}>
                        {this.state.slot1}
                    </div>
                </>
            );
        } else {
            if(this.state.clearIntervalCb) {
                clearInterval(this.state.clearIntervalCb);
                this.setState({clearIntervalCb: null});
            }
            const tens = (number === null) ? 0: Math.floor((number+1)/10);
            const ones = (number === null) ? 0: (number+1)%10;
            return (
                <>
                    <div className="card purple darken-1 col s2" style={{height: '200px', fontSize: '100pt', color: '#FFF'}}>
                        {tens}
                    </div>
                    <div className="card purple darken-1 col s2" style={{height: '200px', fontSize: '100pt', color: '#FFF'}}>
                        {ones}
                    </div>
                </>
            );
        }
    }

    render = () => {
        return (
            <div className="row">
                <div className="col s4"></div>
                {this.slotRender(this.props)}
                <div className="col s4"></div>
                {/* <div>
                    {JSON.stringify(this.props)}
                </div>
                <div>
                    {JSON.stringify(this.state)}
                </div> */}
            </div>
        );
    }
};

export default Slot;