import React from 'react';

import Slot from './Slot';
import Bingo from './Bingo';

const initState = {slotState: 'done', number: null, bingoState: [], numberLog: []};
const APP_KEY = 'bingo-machine-da1-v0';

class App extends React.Component {
    constructor(props) {
        super(props);
        this.state = {...initState};
    }

    restoreLocalStorage = () => {
        const appState = localStorage.getItem(APP_KEY);
        if( appState ) {
            this.setState({...JSON.parse(appState)});
        }
    }

    saveLocalStorage = () => {
        setTimeout(() => {
            localStorage.setItem(APP_KEY, JSON.stringify(this.state));
        }, 5);
    }

    componentDidMount = () => {
        this.setInitState();
        this.restoreLocalStorage();
    }

    setInitState = () => {
        const tempState = [];
        for(let i=0; i<75; i++) {
            tempState.push({open: false, index: i});
        }
        this.setState({bingoState: [...tempState]});
    }

    clearState = () => {
        if(window.confirm('結果を全て消去してやり直して良いですか？')) {
            this.setState({...initState});
            this.setInitState();
            this.saveLocalStorage();
        }
    }

    getOpenState = () => {
        return this.state.bingoState.filter(d => d.open);
    }

    getCloseState = () => {
        return this.state.bingoState.filter(d => !d.open);
    }

    clickHandler = () => {
        if(this.state.slotState !== 'slotting') {
            const closeState = this.getCloseState();

            if(closeState.length !== 0) {
                const audioElm = new Audio();
                audioElm.src = 'se_maoudamashii_instruments_drumroll.mp3';
                audioElm.play();
                this.setState({slotState: 'slotting', number: null});
    
                setTimeout(() => {
                    const numberSelect = closeState[Math.floor(Math.random()*closeState.length)].index;
                    console.log(numberSelect + 1);
                    this.setState({numberLog: [...this.state.numberLog, numberSelect]});
                    this.setState({slotState: 'done', number: numberSelect});
                    this.setState({bingoState: this.state.bingoState.map(d => {
                        if(this.state.number !== null) {
                            if(this.state.number === d.index) {
                                return {open: true, index: d.index};
                            } else {
                                return d;
                            }
                        } else {
                            return d;
                        }
                    })});
                    this.saveLocalStorage();
                }, 5500);
                // }, 2000);
            }
        }
    }

    toggleState = content => {
        const toggleIndex = parseInt(content.target.textContent) - 1;
        this.setState({bingoState: this.state.bingoState.map(d => {
            if(d.index === toggleIndex) {
                return {open: !d.open, index: d.index};
            } else {
                return d;
            }
        })});
        this.saveLocalStorage();
    }

    render() {
        return  (
            <div className="container center-align">
                <Slot state={this.state.slotState} number={this.state.number}/>
                <div className="row">
                    <div className="col s4"></div>
                    <div className="col s4">
                        <button className="waves-effect waves-light red btn" style={{width: '100%'}} onClick={this.clickHandler}>SPIN</button>
                    </div>
                    <div className="col s4"></div>
                </div>
                <Bingo open={this.state.bingoState} toggle={this.toggleState}/>
                <div className="row">
                    <div className="col s5"></div>
                    <div className="col s2">
                            <button className="waves-effect waves-light blue lighten-5 btn" style={{width: '100%', color: '#1e88e5'}} onClick={this.clearState}>RESET</button>
                    </div>
                    <div className="col s5"></div>
                </div>
                {/* <p>音楽：魔王魂</p> */}
            </div>
        )
    }
}

export default App;