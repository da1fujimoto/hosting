self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "f973af82d05d144caf6f50f467770ca2",
    "url": "./index.html"
  },
  {
    "revision": "4677558847db3485b407",
    "url": "./static/js/2.2d59f473.chunk.js"
  },
  {
    "revision": "d705cb622423d72c5defbf368ca70dcc",
    "url": "./static/js/2.2d59f473.chunk.js.LICENSE"
  },
  {
    "revision": "a3a9fa47e69c44944834",
    "url": "./static/js/main.7659da85.chunk.js"
  },
  {
    "revision": "97e6531e6218df50f049",
    "url": "./static/js/runtime-main.57b80e48.js"
  }
]);