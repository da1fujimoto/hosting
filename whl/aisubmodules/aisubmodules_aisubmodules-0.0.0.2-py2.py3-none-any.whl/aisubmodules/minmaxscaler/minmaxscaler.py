#!/usr/bin/env python
# -*- coding: utf-8 -*-
''' Original implementation of MinMaxScaler(for CNN image) '''

import numpy as np


class MinMaxScaler(object):

    def __init__(self, feature_range=(0, 1)):
        if feature_range[0] >= feature_range[1]:
            self._error('unexpected parameter')

        self.params = {
            'feature_range': feature_range,
            'channels': 0,
            'min_max_table': [],
            'fitted': False
        }

    def load_params(self, scale_params):

        assert 'feature_range' in scale_params.keys()
        assert 'channels' in scale_params.keys()
        assert 'min_max_table' in scale_params.keys()

        self.params = {
            'feature_range': scale_params['feature_range'],
            'channels': scale_params['channels'],
            'min_max_table': scale_params['min_max_table'],
            'fitted': True
        }

    def get_params(self):
        
        ret = {
            'feature_range': self.params['feature_range'],
            'channels': self.params['channels'],
            'min_max_table': self.params['min_max_table']
        }
        return ret

    def fit(self, data):
        ''' Compute the minimum and maximum to be used for later scaling. '''
        # The assumed data format is the following two patterns
        # Data format 1: (n, m, v, h): n: Data size, m: Number of channels, v: Vertical, h: Horizontal
        # Data format 2: (n, v, h): n: Data size, v: Vertical, h: Horizontal

        data_dim = data.shape
        if len(data_dim) == 3:
            self.params['channels'] = 1
        elif len(data_dim) == 4:
            self.params['channels'] = data_dim[1]
        else:
            self._error('unexpected data dimension')

        self.params['min_max_table'] = []

        if self.params['channels'] == 1:
            self.params['min_max_table'].append((np.min(data), np.max(data)))
        else:
            for i in range(self.params['channels']):
                self.params['min_max_table'].append(
                    (np.min(data[:, i, :, :]), np.max(data[:, i, :, :])))

        self.params['fitted'] = True

    def transform(self, data):
        ''' Scaling features of 'data' according to feature_range. '''
        if self.params['fitted'] == False:
            self._error('need to call fit() before calling this method.')

        datacopy = np.copy(data)
        data_dim = data.shape

        if len(data_dim) == 3:
            if self.params['channels'] != 1:
                self._error('unexpected data dimension')
            datacopy = self._normalization(
                data,
                self.params['min_max_table'][0][0],
                self.params['min_max_table'][0][1],
                self.params['feature_range'][0],
                self.params['feature_range'][1]
            )
            return datacopy
        elif len(data_dim) == 4:
            for i in range(self.params['channels']):
                datacopy[:, i, :, :] = self._normalization(
                    data[:, i, :, :],
                    self.params['min_max_table'][i][0],
                    self.params['min_max_table'][i][1],
                    self.params['feature_range'][0],
                    self.params['feature_range'][1]
                )
            return datacopy
        else:
            self._error('unexpected data dimension')

    def fit_transform(self, data):
        ''' Fit to data, then transform it. '''
        self.fit(data)
        return self.transform(data)

    def inverse_transform(self, data):
        ''' Undo the scaling of 'data' according to feature_range. '''
        if self.params['fitted'] == False:
            self._error('need to call fit() before calling this method.')
        datacopy = np.copy(data)
        data_dim = data.shape

        if len(data_dim) == 3:
            if self.params['channels'] != 1:
                self._error('unexpected data dimension')
            datacopy = self._unnormalization(
                data,
                self.params['min_max_table'][0][0],
                self.params['min_max_table'][0][1],
                self.params['feature_range'][0],
                self.params['feature_range'][1]
            )
            return datacopy
        elif len(data_dim) == 4:
            for i in range(self.params['channels']):
                datacopy[:, i, :, :] = self._unnormalization(
                    data[:, i, :, :],
                    self.params['min_max_table'][i][0],
                    self.params['min_max_table'][i][1],
                    self.params['feature_range'][0],
                    self.params['feature_range'][1]
                )
            return datacopy
        else:
            self._error('unexpected data dimension')

    def _normalization(self, data, scale_min, scale_max, offset_min, offset_max):
        return ((data - scale_min) / (scale_max - scale_min)) * (offset_max - offset_min) + offset_min

    def _unnormalization(self, data, scale_min, scale_max, offset_min, offset_max):
        return ((data - offset_min) / (offset_max - offset_min)) * (scale_max - scale_min) + scale_min

    def _error(self, str):
        raise Exception(str)
