#!/usr/bin/env python
# -*- coding: utf-8 -*-
''' AI data loader '''

import numpy as np


class DataLoader(object):
    '''
    DataLoader(x_data, y_data, batch_size, shuffle)
     * x_data: data: 1
     * y_data: data: 2
     * batch_size: e.g. 32
     * shuffle: True/False
    '''
    def __init__(self, x_data, y_data, batch_size, shuffle):
        self.x_data = x_data
        self.y_data = y_data
        self.batch_size = batch_size
        self.shuffle = shuffle
        self._num = x_data.shape[0]
        self._i = 0
        if shuffle:
            self.indexs = np.array_split(np.random.permutation(self._num), int(self._num/self.batch_size))
        else:
            self.indexs = np.array_split(np.arange(self._num), int(self._num/self.batch_size))
            
    def __iter__(self):
        return self
    
    def __next__(self):
        if self._i == len(self.indexs):
            if self.shuffle:
                self.indexs = np.array_split(np.random.permutation(self._num), int(self._num/self.batch_size))
            self._i = 0
            raise StopIteration()
        index = self.indexs[self._i]
        ratio = float(len(index)/self._num)
        self._i += 1
        return self.x_data[index], self.y_data[index], ratio
