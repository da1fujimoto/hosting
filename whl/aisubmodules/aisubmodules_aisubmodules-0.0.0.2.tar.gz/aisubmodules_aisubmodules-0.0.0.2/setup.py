from io import open
from os import path, sep
from setuptools import setup, find_packages

here = path.abspath(path.dirname(__file__))

with open(path.join(here, '..', 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

package_name = 'aisubmodules'
prefix = path.abspath(__file__).split(sep)[-2]

version = {}
with open(path.join(here, package_name, '_version.py')) as f:
    exec(f.read(), version)

setup(
    name='{}_{}'.format(package_name, prefix),
    version=version['__version__'],
    description='DUE adjustment AI module',
    url='http://ghe.nanao.co.jp/fujimoto/aifactoryuse/aisubmodules',
    author='EIZO Corporation',
    # author_email='',
    packages=find_packages(exclude=['docs', 'tests']),
    install_requires=[
        'chainer>=2.1.0',
        'pandas>=0.23.1',
        'flask>=1.0.2',
        'flask-cors>=3.0.6'
    ],
    package_data={
        # package_name: ['model_files/*']
    },
    test_suite='tests',
    entry_points={
        'console_scripts': [
            'choseihosting = aisubmodules.choseihosting:main',
        ],
    },
)
