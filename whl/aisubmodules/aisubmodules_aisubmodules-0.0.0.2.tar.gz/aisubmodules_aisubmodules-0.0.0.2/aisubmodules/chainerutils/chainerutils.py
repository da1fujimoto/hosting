#!/usr/bin/env python
# -*- coding: utf-8 -*-
''' Chainer utilities '''

import chainer
from chainer import Link, Chain, ChainList, Variable
import chainer.functions as F
import chainer.links as L


class LINEAR(chainer.Chain):
    '''
    LINEAR was created based on L.Linear
    
    args: in_size, out_size=None, nobias=False, initialW=None, initial_bias=None,
          bn=False, activation=F.relu, bias_after_bn=False
    '''
    def __init__(self, in_size, out_size=None, nobias=False, initialW=None, initial_bias=None,
                 bn=False, activation=F.relu, bias_after_bn=False):
        self.bn = bn
        self.activation = activation
        self.bias_after_bn = bias_after_bn
        
        if bias_after_bn:
            nobias = True # multi bias guard
        layers = {}
        layers['linear'] = L.Linear(in_size=in_size, out_size=out_size, nobias=nobias, initialW=initialW, initial_bias=initial_bias)
        if bn:
            layers['batchnorm'] = L.BatchNormalization(out_size)
        if bias_after_bn:
            layers['bias'] = L.Bias(shape=(out_size))
        super(LINEAR, self).__init__(**layers)
        
    def __call__(self, x):
        h = self.linear(x)
        if self.bn:
            h = self.batchnorm(h)
        if self.bias_after_bn:
            h = self.bias(h)
        if not self.activation is None:
            h = self.activation(h)
        return h


class CNN(chainer.Chain):
    '''
    CNN was created based on L.Convolution2D 
    
    args: in_channels, out_channels, ksize=None, stride=1, pad=0, nobias=False, initialW=None, initial_bias=None,
          bn=False, activation=F.relu, bias_after_bn=False
    '''
    def __init__(self, in_channels, out_channels, ksize=None, stride=1, pad=0, nobias=False, initialW=None, initial_bias=None,
                 bn=False, activation=F.relu, bias_after_bn=False):
        self.bn = bn
        self.activation = activation
        self.bias_after_bn = bias_after_bn
        
        if bias_after_bn:
            nobias = True # multi bias guard
        layers = {}
        layers['cnn'] = L.Convolution2D(in_channels=in_channels, out_channels=out_channels, ksize=ksize, stride=stride, pad=pad,
                                        nobias=nobias, initialW=initialW, initial_bias=initial_bias)
        if bn:
            layers['batchnorm'] = L.BatchNormalization(out_channels)
        if bias_after_bn:
            layers['bias'] = L.Bias(shape=(out_channels))
        super(CNN, self).__init__(**layers)
        
    def __call__(self, x):
        h = self.cnn(x)
        if self.bn:
            h = self.batchnorm(h)
        if self.bias_after_bn:
            h = self.bias(h)
        if not self.activation is None:
            h = self.activation(h)
        return h


class CNNND(chainer.Chain):
    '''
    CNNND was created based on L.ConvolutionND 
    
    args: ndim, in_channels, out_channels,
          ksize=None, stride=1, pad=0, nobias=False, initialW=None, initial_bias=None, cover_all=False,
          bn=False, activation=F.relu, bias_after_bn=False
    '''
    def __init__(self, ndim, in_channels, out_channels,
                 ksize=None, stride=1, pad=0, nobias=False, initialW=None, initial_bias=None, cover_all=False,
                 bn=False, activation=F.relu, bias_after_bn=False):
        self.bn = bn
        self.activation = activation
        self.bias_after_bn = bias_after_bn
        
        if bias_after_bn:
            nobias = True # multi bias guard
        layers = {}
        layers['cnnnd'] = L.ConvolutionND(ndim=ndim, in_channels=in_channels, out_channels=out_channels,
                                          ksize=ksize, stride=stride, pad=pad, nobias=nobias, initialW=initialW, initial_bias=initial_bias, cover_all=cover_all)
        if bn:
            layers['batchnorm'] = L.BatchNormalization(out_channels)
        if bias_after_bn:
            layers['bias'] = L.Bias(shape=(out_channels))
        super(CNNND, self).__init__(**layers)
        
    def __call__(self, x):
        h = self.cnnnd(x)
        if self.bn:
            h = self.batchnorm(h)
        if self.bias_after_bn:
            h = self.bias(h)
        if not self.activation is None:
            h = self.activation(h)
        return h


class DECNN(chainer.Chain):
    '''
    DECNN was created based on L.Deconvolution2D 
    
    args: in_channels, out_channels, ksize=None, stride=1, pad=0, nobias=False, outsize=None, initialW=None, initial_bias=None,
          bn=False, activation=F.relu, bias_after_bn=False
    '''
    def __init__(self, in_channels, out_channels, ksize=None, stride=1, pad=0, nobias=False, outsize=None, initialW=None, initial_bias=None,
                 bn=False, activation=F.relu, bias_after_bn=False):
        self.bn = bn
        self.activation = activation
        self.bias_after_bn = bias_after_bn
        
        if bias_after_bn:
            nobias = True # multi bias guard
        layers = {}
        layers['decnn'] = L.Deconvolution2D(in_channels=in_channels, out_channels=out_channels, ksize=ksize, stride=stride, pad=pad,
                                            nobias=nobias, outsize=outsize, initialW=initialW, initial_bias=initial_bias)
        if bn:
            layers['batchnorm'] = L.BatchNormalization(out_channels)
        if bias_after_bn:
            layers['bias'] = L.Bias(shape=(out_channels))
        super(DECNN, self).__init__(**layers)
        
    def __call__(self, x):
        h = self.decnn(x)
        if self.bn:
            h = self.batchnorm(h)
        if self.bias_after_bn:
            h = self.bias(h)
        if not self.activation is None:
            h = self.activation(h)
        return h


class DICNN(chainer.Chain):
    '''
    DICNN was created based on L.DilatedConvolution2D
    
    args: in_channels, out_channels, ksize=None, stride=1, pad=0, dilate=1, nobias=False, initialW=None, initial_bias=None,
          bn=False, activation=F.relu, bias_after_bn=False
    '''
    def __init__(self, in_channels, out_channels, ksize=None, stride=1, pad=0, dilate=1, nobias=False, initialW=None, initial_bias=None,
                 bn=False, activation=F.relu, bias_after_bn=False):
        self.bn = bn
        self.activation = activation
        self.bias_after_bn = bias_after_bn
        
        if bias_after_bn:
            nobias = True # multi bias guard
        layers = {}
        layers['dicnn'] = L.DilatedConvolution2D(in_channels=in_channels, out_channels=out_channels, ksize=ksize, stride=stride, pad=pad,
                                                 dilate=dilate, nobias=nobias, initialW=initialW, initial_bias=initial_bias)
        if bn:
            layers['batchnorm'] = L.BatchNormalization(out_channels)
        if bias_after_bn:
            layers['bias'] = L.Bias(shape=(out_channels))
        super(DICNN, self).__init__(**layers)
        
    def __call__(self, x):
        h = self.dicnn(x)
        if self.bn:
            h = self.batchnorm(h)
        if self.bias_after_bn:
            h = self.bias(h)
        if not self.activation is None:
            h = self.activation(h)
        return h

if __name__ == '__main__':
    import numpy as np
    
    # LINEAR
    print(LINEAR.__doc__)
    linear = LINEAR(None, 16, bn=True, bias_after_bn=True)
    a = chainer.Variable(np.random.randn(10, 64).astype(np.float32))
    b = linear(a)
    print(a.shape)
    print(b.shape)
    
    # CNN
    print(CNN.__doc__)
    cnn = CNN(None, 16, 3, 1, 1, bn=True, bias_after_bn=True)
    a = chainer.Variable(np.random.randn(10, 2, 8, 8).astype(np.float32))
    b = cnn(a)
    print(a.shape)
    print(b.shape)
    
    # CNNND
    print(CNNND.__doc__)
    cnnnd = CNNND(1, 2, 16, 3, 1, 1, bn=True, bias_after_bn=True)
    a = chainer.Variable(np.random.randn(10, 2, 64).astype(np.float32))
    b = cnnnd(a)
    print(a.shape)
    print(b.shape)
