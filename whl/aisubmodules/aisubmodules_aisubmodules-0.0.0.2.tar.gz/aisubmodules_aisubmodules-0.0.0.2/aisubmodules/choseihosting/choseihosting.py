#!/usr/bin/env python
# -*- coding: utf-8 -*-

import json
import os
import glob

from flask import Flask, jsonify, request, make_response
from flask_cors import CORS


host = '0.0.0.0'
port = 18053
csvpath = '/mnt/windows'

app = Flask(__name__)
CORS(app)


@app.route('/', methods=['GET'])
def route_slash():
    return 'read usage!'


@app.route('/get_csv', methods=['POST'])
def route_get_csv():
    try:
        received_data = json.loads(request.data.decode('utf-8'))

        assert 'model' in received_data.keys()
        assert 'sn' in received_data.keys()
        assert 'filename' in received_data.keys()
        assert '.csv' in received_data['filename']

        file_path = os.path.join(
            csvpath, received_data['model'], received_data['sn'], received_data['filename'])
        print(file_path)

        with open(file_path, 'r') as f:
            readcsv = f.read()

        response = make_response()
        response.data = readcsv
        response.mimetype = 'text/csv'
        return response

    except Exception as ex:
        error_out = 'Error has occurred: {ex}'.format(ex=ex)
        print(error_out)
        return error_out


@app.route('/get_monitors', methods=['POST'])
def route_get_monitors():
    try:
        monlist = glob.glob(csvpath + '/*/')

        mons = []
        for mon in monlist:
            mons.append(mon.split('/')[-2])

        return jsonify(sorted(mons))

    except Exception as ex:
        error_out = 'Error has occurred: {ex}'.format(ex=ex)
        print(error_out)
        return error_out


@app.route('/get_serials', methods=['POST'])
def route_get_serials():
    try:
        received_data = json.loads(request.data.decode('utf-8'))

        assert 'model' in received_data.keys()

        serlist = glob.glob(
            '{basepath}/{model}/*/'.format(basepath=csvpath, model=received_data['model']))

        sers = []
        for ser in serlist:
            sers.append(ser.split('/')[-2])

        return jsonify(sorted(sers))

    except Exception as ex:
        error_out = 'Error has occurred: {ex}'.format(ex=ex)
        print(error_out)
        return error_out


@app.route('/get_files', methods=['POST'])
def route_get_files():
    try:
        received_data = json.loads(request.data.decode('utf-8'))

        assert 'model' in received_data.keys()
        assert 'sn' in received_data.keys()

        filelist = glob.glob('{basepath}/{model}/{sn}/*'.format(
            basepath=csvpath,
            model=received_data['model'],
            sn=received_data['sn'])
        )

        files = []
        for file in filelist:
            files.append(file.split('/')[-1])

        return jsonify(sorted(files))

    except Exception as ex:
        error_out = 'Error has occurred: {ex}'.format(ex=ex)
        print(error_out)
        return error_out


def main():
    import argparse

    global csvpath

    parser = argparse.ArgumentParser(
        description='chosei server file list hosting server')
    parser.add_argument('--host', default='0.0.0.0',
                        help='set host ip address. default: 0.0.0.0')
    parser.add_argument('--port', default='8080',
                        help='set host port number. default: 8080')
    parser.add_argument('--csvpath', default='/mnt/windows',
                        help='csv base path. default: /mnt/windows')
    args = parser.parse_args()

    host = args.host
    port = int(args.port)
    csvpath = args.csvpath

    app.run(host=host, port=port, debug=False)
