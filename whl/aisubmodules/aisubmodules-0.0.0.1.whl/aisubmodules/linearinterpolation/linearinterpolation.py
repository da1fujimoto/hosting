#!/usr/bin/env python
# -*- coding: utf-8 -*-
''' Linear interpolation module '''


def LinearInterpolation(x1, x2, y1, y2, xn):
    ''' Execute linear interpolation '''
    a = (y2 - y1) / (x2 - x1) # gradient 
    b = y1 - (a * x1) # Interception 
    return (a * xn) + b