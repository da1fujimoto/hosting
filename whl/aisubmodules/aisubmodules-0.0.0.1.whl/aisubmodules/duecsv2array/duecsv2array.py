#!/usr/bin/env python
# -*- coding: utf-8 -*-
''' DUE csv to array '''

import io
import numpy as np
import pandas as pd

# TODO: 刷新アプリのcsvフォーマット変更に対応する 

def csv2array(csv_path, params):
    
    if type(csv_path) is io.BytesIO:
        rcsv = csv_path.readline().decode('utf-8')
        csv_path.seek(0)
    else:
        with open(csv_path, 'r') as f:
            rcsv = f.readline()

    # check csv format
    for e, (k, v) in enumerate(sorted(params['MeasureLayers'].items())):
        assert rcsv.split(',')[e*4 + 1] == str(v)
    
    measure_df = pd.read_csv(csv_path)
    
    columns = sum(
        [
            'L{layer_index}_{layer}_LY L{layer_index}_{layer}_sx L{layer_index}_{layer}_sy sp{layer_index}'.format(
                layer_index=layer_index, layer=layer
            ).split() for layer_index, layer in sorted(params['MeasureLayers'].items())
        ],
        []
    )[:len(measure_df.columns)]
    measure_df.columns = columns
    
    # set index name
    measure_df.index.name = "{0}x{1}x{2}".format(1, params['LayerShape'][0], params['LayerShape'][1])
    
    # delete unnecessary columns
    spaces = sum(
        ['sp{layer_index}'.format(layer_index=layer_index).split() for layer_index, _ in sorted(params['MeasureLayers'].items())],
        []
    )[:int(len(measure_df.columns)/4)]
    measure_data = measure_df.drop(spaces, axis=1)

    panel_measure_data = []

    for layer_index, layer in sorted(params['MeasureLayers'].items()):
        layer_names = 'L{layer_index}_{layer}_LY L{layer_index}_{layer}_sx L{layer_index}_{layer}_sy'.format(
            layer_index=layer_index, layer=layer
        ).split()
        panel_measure_data.append(
            np.stack(
                (measure_data[layer_names[0]],
                 measure_data[layer_names[1]],
                 measure_data[layer_names[2]]),
                axis=0
            ).reshape(3, params['LayerShape'][0], params['LayerShape'][1])
        )
    return np.array(panel_measure_data).astype(np.float32)
